Plugin.extend({
    _type: 'org.ekstep.qsquiz',
    _isContainer: true,
    _render: true,
    _pluginConfig: {},
    _pluginData: {},
    _pluginAttributes: {},
    _instance: undefined,
    _qId: undefined,
    initPlugin: function(data) {
        // this._stage._currentState = undefined;
        var instance = this;
        var fontsize = data.fontsize || 20;

        // Init self container
        var dims = this.relativeDims();
        this._self = new createjs.Container();
        this._self.x = dims.x;
        this._self.y = dims.y;
        this._self.w = dims.w;
        this._self.h = dims.h;

        // parse config of the quiz json
        this._pluginConfig = JSON.parse(data.config.__cdata);
        this._pluginData = JSON.parse(data.data.__cdata);
        this._qId = data.id;
        // Init the item controller
        this.initquestionnaire();

        // Invoke templates to templateMap
        this.invokeTemplate();

        // Invoke the embed plugin to start rendering the templates
        this.invokeEmbed();
        this.registerEvents();
    },


    registerEvents: function() {
        var instance = this;
        EkstepRendererAPI.addEventListener("org.ekstep.qsquiz:hide", function() {
            instance._stage.removeChildAt(0);
            instance.update();
        });
        EkstepRendererAPI.addEventListener("org.ekstep.qsquiz:evaluate", function(event) {

            var callback = event.target;
            instance.evaluate(callback, instance);

        });
    },

    invokeTemplate: function() {
        var instance = this;
        var templateType = this._pluginConfig.var || "item";
        var templateId = this._stage.getTemplate(templateType);
        var template = this._theme._templateMap[templateId];
        if (template === undefined) {
            this._pluginData.template.forEach(function(temp) {
                if (temp.id) {
                    // push i.template into the collection arrey of the templates.
                    instance._theme._templateMap[temp.id] = temp;
                }
            });
        }
    },
    invokeEmbed: function() {
        var embedData = {};
        embedData.template = this._pluginConfig.var || "item";
        embedData["var-item"] = this._pluginConfig.var || "item";
        // this.setState('mcq', undefined, false);
        PluginManager.invoke('embed', embedData, this, this._stage, this._theme);
    },
    initquestionnaire: function() {
        var controllerName = "item";
        console.log("this._theme", this._theme);
        var assessmentid = (this._qId + "_assessment");
        // var assessmentid = (this._stage._id + "_assessment");
        var stageController = this._theme._controllerMap[assessmentid];

        // Check if the controller is already initialized, if yes, skip the init
        var initialized = (stageController != undefined);
        if (!initialized) {
            var controllerData = {};
            controllerData.__cdata = this._pluginData.questionnaire;
            controllerData.type = this._pluginConfig.type;
            controllerData.name = assessmentid;
            controllerData.id = assessmentid;

            this._theme.addController(controllerData);
            stageController = this._theme._controllerMap[assessmentid];
        }

        if (stageController) {
            this._stage._stageController = stageController;
            this._stage._stageControllerName = controllerName; //+ Math.random();
            this._stage._stageController.reset();
            this._stage._stageController.next();
            var stageKey = this._stage.getStagestateKey();
            if (typeof this._theme.getParam === "function") {
                this._stage._currentState = this._theme.getParam(stageKey);
                /*  if (_.isUndefined(this._stage._currentState)) {
                      if(this._stage.getParam('mcq')){
                          this._stage.setParam("mcq",undefined);
                      }
                     
                      this._stage.setParam(this._stage._type, {
                          id: this._theme._currentStage,
                          stateId: stageKey
                      });
                  }*/
            }
        }
    },
    evaluate: function(callback, instance) {
        // var item = this._pluginData.questionnaire;
        // console.log("item", item);
        var result = {};
        var pass = true;
        var score = 0;
        var res = [];
        console.log(_instance._theme._currentScene._currentState);
        if (_instance._theme._currentScene._currentState) {
            var options = _instance._theme._currentScene._currentState.mcq;
            if (_.isArray(options)) {
                var isMCQ = false;
                var answersCount = 0;
                options.forEach(function(opt) {
                    if (opt.answer == true) {
                        answersCount++;
                    }
                });
                if (answersCount > 1) {
                    //if multiple ans is present then it is MMCQ
                    isMCQ = false;
                } else if (answersCount == 1) {
                    //if answer count is equalto one then it is MCQ
                    isMCQ = true;
                } else {
                    console.warn("Its not MCQ and MMCQ");
                    return;
                }
                options.forEach(function(opt) {

                    // remember in telemetry what the response was
                    if (opt.selected) {
                        var tuple = {};
                        tuple[opt.value.resvalue] = "true";
                        res.push(tuple);
                    }

                    // evaluate if this is correct answer
                    if (opt.answer === true) {
                        if (!opt.selected) {
                            pass = false;
                        } else {
                            score += (_.isNumber(opt.score)) ? opt.score : 1;
                        }
                    } else {
                        if (opt.selected === true) {
                            pass = false;
                            if (isMCQ == true)
                                delete opt.selected;
                        }
                    }
                });
            }
            // if (!pass) {
            //     result.feedback = item.feedback;
            //     if (!item.partial_scoring) {
            //         score = 0;
            //     }
            // }
        }
        result.eval = pass;
        result.score = score;
        result.res = res;
        //return result;

        // if (item.type.toLowerCase() == 'ftb') {
        //     result = FTBEvaluator.evaluate(item);
        // } else if (item.type.toLowerCase() == 'mcq' || item.type.toLowerCase() == 'mmcq') {
        //     result = MCQEvaluator.evaluate(item);
        // } else if (item.type.toLowerCase() == 'mtf') {
        //     result = MTFEvaluator.evaluate(item);
        // }


        if (_.isFunction(callback)) {
            callback(result);
        }
    },

    // evalListener: function(event) {
    //     var callback = event.target;
    //     _instance.evaluate(callback);
    // },
    // hideListner: function() {
    //     // this._instance.hide();
    //     this._stage.removeChildAt(0);
    //     this._instance.destroy();
    // }


});
//# sourceURL=qsquizRenderer.js