org.ekstep.contentrenderer.questionUnitPlugin = Plugin.extend({
    _type: 'org.ekstep.questionUnitPlugin',
    _render: true,
    //TODO: Interfaces
    initPlugin: function(data) {
    	console.log('qu-data--->', data);
    }
});