var audiManager = {
	getAudiManager : function(){
		return AudioManager;
	},
	getEvenManager: function(){
		return EventManager;
	},
	getContManager: function(){
		return ControllerManager;
	},
	getCmdManager: function(){
		return CommandManager;
	}
}